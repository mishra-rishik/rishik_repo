import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { HttpModule } from '@angular/http';
import { RouterModule, Routes } from '@angular/router';

import { AppComponent } from './app.component';
import { AddTaskComponent } from './add-task/add-task.component';
import { ViewTaskComponent } from './view-task/view-task.component';
import { TaskService } from './task.service';
import { EditTaskComponent } from './edit-task/edit-task.component';
import { ComboSearchPipePipe } from './combo-search-pipe.pipe';


const routes: Routes = [
  { path: 'addTask', component: AddTaskComponent },
  { path: 'viewAll', component: ViewTaskComponent },
  { path: '', component: ViewTaskComponent },
  { path: 'editTask/:taskId', component: EditTaskComponent }
];

@NgModule({
  exports: [ RouterModule ],

  declarations: [
    AppComponent,
    AddTaskComponent,
    ViewTaskComponent,
    EditTaskComponent,
    ComboSearchPipePipe
  ],
  imports: [
    BrowserModule,
    FormsModule,
    HttpModule,
    RouterModule.forRoot(routes)
  ],
  providers: [TaskService],
  bootstrap: [AppComponent]
})
export class AppModule { }
