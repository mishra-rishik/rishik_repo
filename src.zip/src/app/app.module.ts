import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { HttpModule } from '@angular/http';
import { RouterModule, Routes } from '@angular/router';

import { AppComponent } from './app.component';
import { WorkOutCategoryComponent } from './work-out-category/work-out-category.component';
import { WorkoutCategoryService } from './workout-category.service';
import { SearchPipe } from './search.pipe';
import { WorkoutComponent } from './workout/workout.component';
import { ViewAllComponent } from './view-all/view-all.component';
import { EditWorkoutComponent } from './edit-workout/edit-workout.component'

const routes: Routes = [
  { path: 'category', component: WorkOutCategoryComponent },
  { path: 'createWO', component: WorkoutComponent },
  { path: 'viewAll', component: ViewAllComponent },
  { path: 'editWO/:workoutTitle', component: EditWorkoutComponent }
];

@NgModule({
  exports: [ RouterModule ],

  declarations: [
    AppComponent,
    WorkOutCategoryComponent,
    SearchPipe,
    WorkoutComponent,
    ViewAllComponent,
    EditWorkoutComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    HttpModule,
    RouterModule.forRoot(routes)
  ],
  providers: [WorkoutCategoryService],
  bootstrap: [AppComponent]
})
export class AppModule { }
