export class WorkOut {
    public workoutId : number;
    public workOutTitle : string;
    public calsBurntPerUnit : number;
    public unit : string;

    public constructor(){
        
    }
}
