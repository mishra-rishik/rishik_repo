export class TimerData {
    public hours : number = 0;
    public minutes : number = 0;
    public seconds : number = 0;
}
