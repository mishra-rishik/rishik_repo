import { Component, OnInit } from '@angular/core';
import { Category } from '../category';
import {WorkoutCategoryService} from '../workout-category.service';
import { SearchPipe } from '../search.pipe';


@Component({
  selector: 'app-work-out-category',
  templateUrl: './work-out-category.component.html',
  styleUrls: ['./work-out-category.component.css'],
        
})
export class WorkOutCategoryComponent implements OnInit {
  
  workoutCategoryService : WorkoutCategoryService;
  category : Category;
  filterText : string = '';
  editableFlag : String = 'Edit';
  

  constructor(workoutCategoryService : WorkoutCategoryService) {
    this.workoutCategoryService = workoutCategoryService;
    this.category = new Category();
   }

  ngOnInit() {
  }

  add(){
    this.workoutCategoryService.addWorkOutCat(this.category);
    this.category = new Category();
        
  }

  delete(category : Category){
    this.workoutCategoryService.deleteWorkOutCat(category);
    
  }

  clickEvent(category : Category){
    if(!category.catEditable){
      category.catEditable = true;
      category.buttonFlag = 'Update';
    }else if(category.buttonFlag = 'Update'){
      category.catEditable = false;
      category.buttonFlag = 'Edit';
    }
        
  }

}
