export class WorkOutUser {

    public userId : number;
    public userName : string;
    public password : string;
    public retypePassword : string;

    public constructor(){
        
    }
    

}
