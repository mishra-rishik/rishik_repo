export class Category {
    public categoryId : number;
    public categoryTitle : string;
    public catEditable : boolean = false;
    public buttonFlag : string = 'Edit';

    constructor(){
       
    }

        
}
