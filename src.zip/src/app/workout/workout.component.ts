import { Component, OnInit } from '@angular/core';
import {WorkoutCategoryService} from '../workout-category.service';
import { Workout } from 'app/workout';

@Component({
  selector: 'app-workout',
  templateUrl: './workout.component.html',
  styleUrls: ['./workout.component.css']
})
export class WorkoutComponent implements OnInit {

  workoutCategoryService : WorkoutCategoryService;
  workout : Workout;

  constructor(workoutCategoryService : WorkoutCategoryService) {
    this.workoutCategoryService = workoutCategoryService;
    this.workout = new Workout();
   }

  ngOnInit() {
  }

  addWorkOut(){
    this.workoutCategoryService.addWorkOut(this.workout);
    this.workout = new Workout();
  }

  plus(){
    this.workout.calsPerMin = this.workout.calsPerMin + 0.1;
  }

  minus(){
    if(this.workout.calsPerMin >= 0.1){
      this.workout.calsPerMin = this.workout.calsPerMin - 0.1;
      if(this.workout.calsPerMin < 0){
        this.workout.calsPerMin = 0;
      }
    }
  }

}
