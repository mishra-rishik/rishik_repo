import { Pipe, PipeTransform } from '@angular/core';
import { TaskSearch } from './task-search';
import { Task } from './task';

@Pipe({
  name: 'comboSearchPipe'
})
export class ComboSearchPipePipe implements PipeTransform {

  transform(value : any[], srTNm : string , srPNm : string , srPrFrom : number , srPrTo : number , srSDt : Date) {
    
    if (value && value.length){
      return value.filter(item =>{
          if (srTNm && item.taskName.toLowerCase().indexOf(srTNm.toLowerCase()) === -1){
              return false;
          }
          if(srPNm){
            if(item.parentTask != null && item.parentTask.parentTaskName != ''){

              if (item.parentTask.parentTaskName.toLowerCase().indexOf(srPNm.toLowerCase()) === -1){
                return false;
              }
  
            }
          }
                    
          if(srPrFrom && item.priority < srPrFrom){
              return false;
          }
          if(srPrTo && item.priority > srPrTo){
              return false;
          }
          if(srSDt && item.startDate < srPrTo){
              return false;
          }
          /*
          if (srPNm && item.parentTask && item.parentTask.parentTaskName.toLowerCase().indexOf(srPNm.toLowerCase()) === -1){
              return false;
          }
                    
          if (companySearch && item.company.toLowerCase().indexOf(companySearch.toLowerCase()) === -1){
              return false;
          }*/
          return true;
     })
    }
    else{
      return value;
    }
    
  }

}
