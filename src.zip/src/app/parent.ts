export class Parent {
    public parentTaskId : number;
    public parentTaskName : string;

    constructor(){
        
    }
}
