export class WorkOutTxn {
    public transactionId : number;
    public calBurnt : number;
    public startTime : Date;
    public endTime : Date;

    public constructor(){
        
    }
}
