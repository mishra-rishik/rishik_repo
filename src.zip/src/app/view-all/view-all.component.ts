import { Component, OnInit } from '@angular/core';
import {WorkoutCategoryService} from '../workout-category.service';
import { SearchPipe } from '../search.pipe';
import { Workout } from 'app/workout';
import { Router } from '@angular/router';

@Component({
  selector: 'app-view-all',
  templateUrl: './view-all.component.html',
  styleUrls: ['./view-all.component.css']
})
export class ViewAllComponent implements OnInit {

  workoutCategoryService : WorkoutCategoryService;
  workout : Workout;
  searchText : string = '';
  //router : Router;

  constructor(workoutCategoryService : WorkoutCategoryService, private router: Router) {
    this.workoutCategoryService = workoutCategoryService;
  }

  ngOnInit() {
  }

  deleteWorkout(workout:Workout){
    this.workoutCategoryService.deleteWorkout(workout);
  }

  editWorkout(workout:Workout){
    //this.workoutCategoryService.editWorkout(workout);
    this.router.navigateByUrl('/editWO/' + workout.workoutTitle);
  }

}
