import { Parent } from "./parent";

export class Task {
    public taskId : number;
    public taskName : string;
    public priority : number;
    public startDate : Date;
    public endDate : Date;
    public actualStartDate : Date;
    public actualEndDate : Date;
    public parentTask : Parent;
    public editFlag : boolean = true;
    public parentName : string;
    public pId : number;

    constructor(){
        
    }
    
}
