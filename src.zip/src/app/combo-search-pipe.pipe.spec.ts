/* tslint:disable:no-unused-variable */

import { TestBed, async } from '@angular/core/testing';
import { ComboSearchPipePipe } from './combo-search-pipe.pipe';

describe('ComboSearchPipePipe', () => {
  it('create an instance', () => {
    const pipe = new ComboSearchPipePipe();
    expect(pipe).toBeTruthy();
  });
});
