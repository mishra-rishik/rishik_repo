import { Pipe, PipeTransform, Injectable } from '@angular/core';
import { Category } from './category';
import { Workout } from './workout';

@Pipe({
  name: 'searchTextFilter'
})


export class SearchPipe implements PipeTransform {

  transform(value : any[], args : string) : any[] {
    if(!args){
      return value;
    }else if(value){
      return value.filter(item => {
        if(item instanceof Category){
          return item.categoryTitle.startsWith(<string> args);
        }else if(item instanceof Workout){
          return item.workoutTitle.startsWith(<string> args);
        }
                
      });
    }
  }   
  

}
