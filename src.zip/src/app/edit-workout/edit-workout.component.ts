import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import {WorkoutCategoryService} from '../workout-category.service';
import { Workout } from '../workout';

@Component({
  selector: 'app-edit-workout',
  templateUrl: './edit-workout.component.html',
  styleUrls: ['./edit-workout.component.css']
})
export class EditWorkoutComponent implements OnInit {

  route : ActivatedRoute;
  workout : Workout;
  workoutId : number;
  workoutCategoryService : WorkoutCategoryService;
  workoutTitle : string;
  //catArr : Category[];

  constructor(route : ActivatedRoute, workoutCategoryService : WorkoutCategoryService) { 
    this.route = route;
    this.workoutCategoryService = workoutCategoryService;
    
  }

  ngOnInit() {
    this.route.params.subscribe(params => {
      
      //this.workoutId = params['workoutID'];
      this.workoutTitle = params['workoutTitle'];
      this.workout = this.workoutCategoryService.getWorkOut(this.workoutTitle);
        
      });
  }

  updateWorkOut(workout : Workout){
    this.workoutCategoryService.updateWorkout(workout);
  }

}
