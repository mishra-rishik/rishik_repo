import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { TaskService } from '../task.service';
import { Task } from '../task';
import { Parent } from '../parent';

@Component({
  selector: 'app-edit-task',
  templateUrl: './edit-task.component.html',
  styleUrls: ['./edit-task.component.css']
})
export class EditTaskComponent implements OnInit {

  route : ActivatedRoute;
  taskService : TaskService;
  task : Task;
  taskId : number;
  taskArr : Task[];
  parentTask : Parent;

  constructor(route : ActivatedRoute, taskService : TaskService) { 
    this.route = route;
    this.taskService = taskService;
    this.task = new Task();
  }

  ngOnInit() {
    this.route.params.subscribe(params => {
      
      this.taskId = params['taskId'];
      // = this.taskService.getTask(this.taskId);
      //alert('Task ID in Edit Task :: ' + this.taskId);
    
      this.taskService.getTask(this.taskId).subscribe(data => {
        this.task = data;
        this.parentTask = this.task.parentTask;
        //alert('Fetched Task Id ' + this.task.taskId);
        //alert('Fetched Task Name ' + this.task.taskName);
                
      }, err => {alert('Service temporarily unavailable')});
        
    });

    this.taskService.getTaskList().subscribe(data => {
      this.taskArr = data;
    }, err => {alert('Service temporarily unavailable')});
      
  }

  updateTask(){

    this.taskService.updateTask(this.task).subscribe(data => {
      this.task = data;
      alert('Task sucessfully updated');
            
      }, err => {alert('Service temporarily unavailable')}
    );
  }

}
