export class TaskSearch {
  searchTaskName : string;
  searchParentName : string;
  searchPriorityFrom : number;
  searchPriorityTo : number;
  searchStartDate : Date;
  searchEndDate : Date;

  constructor(){
      
  }
}
