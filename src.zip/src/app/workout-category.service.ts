import { Injectable } from '@angular/core';
import { Category } from 'app/category';
import { Workout } from 'app/workout';

@Injectable()
export class WorkoutCategoryService {

  workOutCategory : Category[];

  workoutArr : Workout[];

  constructor() {
    this.workOutCategory =[];
    this.workoutArr = [];
   }

   addWorkOutCat(cat : Category){
    this.workOutCategory.push(cat);
   }

   deleteWorkOutCat( category : Category){
    var index = this.workOutCategory.indexOf(category);
    if (index !== -1) {
      this.workOutCategory.splice(index,1);
    }
    
    //this.workOutCategory.dele
   }

  updateWorkOutCat( cat : Category){
    let categoryIndex = -1;
    for(let i=0;i<this.workOutCategory.length;i++){
      if(this.workOutCategory[i].categoryId==cat.categoryId){
        categoryIndex=i;
        break;
      }
    }

    if(categoryIndex>-1){
      this.workOutCategory[categoryIndex] = cat;
    }
  }

  addWorkOut(workout : Workout){
    this.workoutArr.push(workout);
  }

  updateWorkout(workout : Workout){
    let woIndex = -1;
    for(let i=0;i<this.workoutArr.length;i++){
      if(this.workoutArr[i].workoutTitle==workout.workoutTitle){
        woIndex=i;
        break;
      }
    }

    if(woIndex>-1){
      this.workoutArr[woIndex] = workout;
    }
  }

  deleteWorkout(workout : Workout){
    var index = this.workoutArr.indexOf(workout);
    if (index !== -1) {
      this.workoutArr.splice(index,1);
    }
  }

  getWorkOut(workoutTitle : string) : Workout{
    
    let woIndex = -1;
    for(let i=0;i<this.workoutArr.length;i++){
      if(this.workoutArr[i].workoutTitle==workoutTitle){
        //woIndex=i;
        return this.workoutArr[i];
        //break;
      }
    }
    
  }

}
