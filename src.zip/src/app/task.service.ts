import { Injectable } from '@angular/core';
import { environment } from 'environments/environment';
import { Headers, Http, RequestOptions, RequestMethod } from '@angular/http';
import { Task } from './task';
import { Observable } from 'rxjs/Rx';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/do';
import 'rxjs/add/operator/catch';


@Injectable()
export class TaskService {

  url: string;
    
  constructor(private http : Http) {
    this.url = environment.tmBaseAPIUrl + 'tasks/';
  }

  addTask(task : Task){
    
    let headers = new Headers({ 'Content-Type': 'application/json' });
    let options = new RequestOptions({ headers : headers });
    return this.http.post(this.url, task, options)
    .map((res) => (res.status == 201));  
    
  } 
    
  
  getTaskList(){
    return this.http.get(this.url).map(res => res.json());
  }

  getTask(taskId : number){
    let cpHeaders = new Headers({ 'Content-Type': 'application/json' });
    let options = new RequestOptions({ headers: cpHeaders });
    return this.http.get(this.url + taskId, options)
      .map(res => res.json());
  }

  updateTask(task : Task){

    let cpHeaders = new Headers({ 'Content-Type': 'application/json' });
    let options = new RequestOptions({ headers: cpHeaders });

    return this.http.put(this.url + task.taskId, JSON.stringify(task), options)
      .map(res => res.json());
    
  }

  deleteTask(taskId : number){
    return this.http.put(this.url, JSON.stringify(taskId))
      .map(res => res.json());
  }

  private handleError(error: any): Promise<any> {
    console.error('Error', error); 
    return Promise.reject(error.message || error);
  }

}
