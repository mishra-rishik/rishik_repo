/* tslint:disable:no-unused-variable */

import { TestBed, async, inject } from '@angular/core/testing';
import { WorkoutCategoryService } from './workout-category.service';

describe('WorkoutCategoryService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [WorkoutCategoryService]
    });
  });

  it('should ...', inject([WorkoutCategoryService], (service: WorkoutCategoryService) => {
    expect(service).toBeTruthy();
  }));
});
