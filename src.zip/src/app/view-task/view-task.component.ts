import { Component, OnInit } from '@angular/core';
import { TaskService } from '../task.service';
import { Task } from '../task';
import { Parent } from '../parent';
import { DatePipe } from '@angular/common';
import { Router } from '@angular/router';
import { TaskSearch } from '../task-search';
import { ComboSearchPipePipe } from '../combo-search-pipe.pipe';

@Component({
  selector: 'app-view-task',
  templateUrl: './view-task.component.html',
  styleUrls: ['./view-task.component.css']
})
export class ViewTaskComponent implements OnInit {

  taskArr : Task[];
  taskService : TaskService;
  parentName : string;
  task : Task;
  isErr : boolean = false;
  errMsg : string;
  pTask : Task;

  searchTaskObj : TaskSearch;
  srTNm : string;
  srPNm : string;
  srPrFrom : number;
  srPrTo : number;
  srSDt : Date;
  srEDt : Date;
  

  constructor(taskService : TaskService, private router: Router) { 
    this.taskService = taskService;
    this.searchTaskObj = new TaskSearch();
  }

  ngOnInit() {

    this.errMsg = '';

    this.taskService.getTaskList().subscribe(data => {
      this.taskArr = data;
      let tk : Task;
      for(let i = 0 ; i < this.taskArr.length ; i++){
        tk = this.taskArr[i];
        if(tk.actualEndDate != null){
          tk.editFlag = false;
        }
      }
      
    }, err => {alert('Service temporarily unavailable')});
  }

  endTask(task : Task){
    if(task != null){

      if(task.parentTask != null){

        this.taskService.getTask(task.parentTask.parentTaskId).subscribe(data => {
          this.pTask = data;
          if(this.pTask.actualEndDate == null){
            this.isErr = true;
            this.errMsg = 'You cannot end this task before parent task is ended.';
          }
          
        }, err => {alert('Service temporarily unavailable')});

      }else{
        task.actualEndDate = new Date();

        this.taskService.updateTask(task).subscribe(data => {
          this.task = data;
          if(this.task.actualEndDate != null){
            //let dp = new DatePipe('de-DE' /* locale .. */);
            //this.stDt = dp.transform(this.task.startDate, 'dd-MM-yyyy');
            alert('Task : ' + this.task.taskName + ' finished on :' + this.task.actualEndDate);
          }
          
        }, err => {alert('Service temporarily unavailable')});
      }

      
    }
  }

  editTask(task : Task){
    if(task != null){
      alert('to edit :: ' + task.taskId);

      this.router.navigateByUrl('/editTask/' + task.taskId);
    }
  }

}
