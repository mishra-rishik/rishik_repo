export class Workout {
    public workoutId : number;
    public workoutTitle : string;
    public workoutNote : string;
    public calsPerMin : number = 0.0;
    public workoutCat : string;

    constructor(){
       
    }
}
