/**
 * 
 */
package com.rm.fsd.springboot.taskManager.service;

import java.util.List;

import com.rm.fsd.springboot.taskManager.dto.Task;
import com.rm.fsd.springboot.taskManager.util.TaskManagerBusinessServiceException;

/**
 * @author RM
 *
 */
public interface ITaskManagerService {

	List<Task> getAllTasks();
	
	Task getTaskByID(Long taskId);
		
	boolean saveTask(Task task);
	
	boolean updateTask(Task task);
	
	boolean deleteTask(Long taskId);
}
