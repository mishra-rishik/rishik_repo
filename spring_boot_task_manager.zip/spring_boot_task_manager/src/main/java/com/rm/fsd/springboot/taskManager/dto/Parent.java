/**
 * 
 */
package com.rm.fsd.springboot.taskManager.dto;

import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

import com.fasterxml.jackson.annotation.JsonAutoDetect;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

/**
 * @author RM
 *
 */

@Entity
@Table(name = "PARENT_TASK")
//@JsonAutoDetect
//@JsonIgnoreProperties({"hibernateLazyInitializer", "handler"})
public class Parent implements Comparable<Parent> {

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name = "PARENT_ID")
	private Long parentTaskId;
		
	@Column(name="PARENT_TASK")
	private String parentTaskName;
	
	/*@OneToMany(mappedBy = "parentTask", fetch = FetchType.LAZY)
	@JsonIgnore
	private Set<Task> tasks;*/
	
	public Long getParentTaskId() {
		return parentTaskId;
	}

	public void setParentTaskId(Long parentTaskId) {
		this.parentTaskId = parentTaskId;
	}

	public String getParentTaskName() {
		return parentTaskName;
	}

	public void setParentTaskName(String parentTaskName) {
		this.parentTaskName = parentTaskName;
	}
	
	/*public Set<Task> getTasks() {
		return tasks;
	}

	public void setTasks(Set<Task> tasks) {
		this.tasks = tasks;
	}*/

	@Override
	public int compareTo(Parent pt) {
		// TODO Auto-generated method stub
		return this.parentTaskId.compareTo(pt.parentTaskId);
	}
	
	
}
