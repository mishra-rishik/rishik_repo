package com.rm.fsd.springboot.taskManager;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootTaskManagerApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootTaskManagerApplication.class, args);
	}
}
