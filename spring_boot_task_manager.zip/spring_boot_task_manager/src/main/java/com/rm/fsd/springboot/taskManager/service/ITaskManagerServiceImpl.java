/**
 * 
 */
package com.rm.fsd.springboot.taskManager.service;

import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.rm.fsd.springboot.taskManager.dao.ITaskManagerDAO;
import com.rm.fsd.springboot.taskManager.dto.Task;


/**
 * @author RM
 *
 */

@Service
public class ITaskManagerServiceImpl implements ITaskManagerService {
	
	@Autowired
	private ITaskManagerDAO taskManagerDAO;

	@Override
	public List<Task> getAllTasks() {
		// TODO Auto-generated method stub
		return taskManagerDAO.findAll();
	}
	
	@Override
	public Task getTaskByID(Long taskId) {
		// TODO Auto-generated method stub
		Optional<Task> ot = taskManagerDAO.findById(taskId);
		return ot.isPresent() ? ot.get() : null;
	}

	@Transactional
	@Override
	public boolean saveTask(Task task) {
		boolean transFlag = false;
		// TODO Auto-generated method stub
		taskManagerDAO.save(task);
		transFlag = true;
		return transFlag;
	}

	@Transactional
	@Override
	public boolean updateTask(Task task) {
		boolean transFlag = false;
		// TODO Auto-generated method stub
		taskManagerDAO.save(task);
		transFlag = true;
		return transFlag;
	}

	@Transactional
	@Override
	public boolean deleteTask(Long taskId) {
		boolean transFlag = false;
		// TODO Auto-generated method stub
		taskManagerDAO.deleteById(taskId);
		transFlag = true;
		return transFlag;
	}

	public ITaskManagerDAO getTaskManagerDAO() {
		return taskManagerDAO;
	}

	public void setTaskManagerDAO(ITaskManagerDAO taskManagerDAO) {
		this.taskManagerDAO = taskManagerDAO;
	}

	

}
