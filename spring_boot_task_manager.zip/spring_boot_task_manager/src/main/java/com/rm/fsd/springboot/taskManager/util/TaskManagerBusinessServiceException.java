/**
 * 
 */
package com.rm.fsd.springboot.taskManager.util;

import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.http.HttpStatus;

/**
 * @author RM
 *
 */

@ResponseStatus(HttpStatus.NOT_FOUND)
public class TaskManagerBusinessServiceException extends Exception {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public TaskManagerBusinessServiceException(String exception) {
	    super(exception);
	  }

}
