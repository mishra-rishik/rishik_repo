/**
 * 
 */
package com.rm.fsd.springboot.taskManager;

import static org.assertj.core.api.Assertions.assertThat;

import java.util.Optional;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase.Replace;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.boot.test.autoconfigure.orm.jpa.TestEntityManager;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.context.TestConfiguration;
import org.springframework.context.annotation.Bean;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.context.junit4.SpringRunner;

import com.rm.fsd.springboot.taskManager.dao.ITaskManagerDAO;
import com.rm.fsd.springboot.taskManager.dto.Task;
import com.rm.fsd.springboot.taskManager.service.ITaskManagerServiceImpl;
import com.rm.fsd.springboot.taskManager.util.ConfigProperties;

/**
 * @author RM
 *
 */

@RunWith(SpringRunner.class)
@DataJpaTest
@AutoConfigureTestDatabase(replace = Replace.NONE)
@SpringBootTest
@TestPropertySource(locations = "classpath:taskManager-integrationtest.properties")
public class TaskManagerDAOTest {
	
		
	@Autowired
    private TestEntityManager entityManager;
 
    @Autowired
    private ITaskManagerDAO taskManagerDAO;
    
    //@Autowired
    //ConfigProperties configProperties;
        
        
    @Test
    public void whenFindById_thenReturnTask() {
        // given
        Task testDaoTask = new Task();
        //testDaoTask.setTaskName(configProperties.getTestDaoTaskName());
        testDaoTask.setTaskName("t3");
        entityManager.getId(testDaoTask); //persist(testDaoTask);
       // entityManager.flush();
     
        // when
        Optional<Task> foundTask = taskManagerDAO.findById(new Long(4));
     
        // then
        assertThat(foundTask.get().getTaskName())
          .isEqualTo(testDaoTask.getTaskName());
    }
    

}
