/**
 * 
 */
package com.rm.fsd.springboot.skillTracker.helper;

import java.awt.image.BufferedImage;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import javax.imageio.ImageIO;
import javax.imageio.ImageReader;
import javax.imageio.stream.ImageInputStream;

/**
 * @author rishi
 *
 */
public class TiffHelper {
	
	public List<BufferedImage> extractImages(InputStream fileInput) throws Exception {
	    List<BufferedImage> extractedImages = new ArrayList<BufferedImage>();

	    try (ImageInputStream iis = ImageIO.createImageInputStream(fileInput)) {

	        ImageReader reader = getTiffImageReader();
	        reader.setInput(iis);

	        int pages = reader.getNumImages(true);
	        for (int imageIndex = 0; imageIndex < pages; imageIndex++) {
	            BufferedImage bufferedImage = reader.read(imageIndex);
	            extractedImages.add(bufferedImage);
	        }
	    }

	    return extractedImages;
	}

	private ImageReader getTiffImageReader() {
	    Iterator<ImageReader> imageReaders = ImageIO.getImageReadersByFormatName("TIFF");
	    if (!imageReaders.hasNext()) {
	        throw new UnsupportedOperationException("No TIFF Reader found!");
	    }
	    return imageReaders.next();
	}

}
