/* tslint:disable:no-unused-variable */

import { TestBed, async } from '@angular/core/testing';
import { AssociateSearchPipe } from './associate-search.pipe';

describe('AssociateSearchPipe', () => {
  it('create an instance', () => {
    const pipe = new AssociateSearchPipe();
    expect(pipe).toBeTruthy();
  });
});
