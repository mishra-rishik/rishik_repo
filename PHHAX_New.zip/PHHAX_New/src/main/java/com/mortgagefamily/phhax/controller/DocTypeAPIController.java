/**
 * 
 */
package com.mortgagefamily.phhax.controller;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import javax.validation.Valid;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.mortgagefamily.phhax.cdms.dto.DocType;
import com.mortgagefamily.phhax.cdms.dto.DocTypeCat;
import com.mortgagefamily.phhax.service.IDocTypeService;



/**
 * @author RM
 *
 */

@RestController
@RequestMapping("/docmaster")
@CrossOrigin(origins = {"http://localhost:4200"})
public class DocTypeAPIController {
	
	//final static Logger logger = Logger.getLogger(DocTypeAPIController.class.getName());

	@Autowired
	private IDocTypeService docTypeService;
		
	@CrossOrigin(origins = {"http://localhost:4200"})
	@GetMapping(value="/",  produces=MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<List<DocTypeCat>> getAllDocCategories() {
		System.out.println("Enter DocTypeAPIController - getAllDocCategories()");
		ResponseEntity<List<DocTypeCat>> result = null;
		
		try {
			List<DocTypeCat> docCatList = docTypeService.getAllDocTypeCats();
			
			if(docCatList != null) {
				System.out.println("Doc category list size :: " + docCatList.size());
				
				for(DocTypeCat docTypeCat : docCatList) {
					Set<DocType> docTypeSet = docTypeCat.getDocTypes();
				}
				
				result = new ResponseEntity<List<DocTypeCat>>(docCatList, HttpStatus.OK);
			}else {
				result = new ResponseEntity<List<DocTypeCat>>(docCatList, HttpStatus.NOT_FOUND);
			}
		}catch(Exception ex) {
			System.out.println("Enter DocTypeAPIController - getAllDocCategories()");
			ex.printStackTrace();
		}
		
		System.out.println("Exit DocTypeAPIController - getAllDocCategories()");
		return result;
		
	}
		
}
