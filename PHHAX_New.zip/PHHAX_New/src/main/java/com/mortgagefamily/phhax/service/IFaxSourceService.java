package com.mortgagefamily.phhax.service;

import java.util.List;

import com.mortgagefamily.phhax.sybmt.dto.FaxSource;



public interface IFaxSourceService {

	List<FaxSource> getAllFaxSources();
}
