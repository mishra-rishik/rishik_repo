/**
 * 
 */
package com.mortgagefamily.phhax.controller;

import java.util.List;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.mortgagefamily.phhax.service.IFaxSourceService;
import com.mortgagefamily.phhax.sybmt.dto.FaxSource;

/**
 * @author mishrari
 *
 */

@RestController
@RequestMapping("/phhaxsrc")
@CrossOrigin(origins = {"http://localhost:4200"})
public class FaxSourceAPIController {

	@Autowired
	private IFaxSourceService faxSourceService;
		
	@CrossOrigin(origins = {"http://localhost:4200"})
	@GetMapping(value="/",  produces=MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<List<FaxSource>> getAllFaxSources() {
		System.out.println("Enter DocTypeAPIController - getAllFaxSources()");
		ResponseEntity<List<FaxSource>> result = null;
		
		try {
			List<FaxSource> faxSourceList = faxSourceService.getAllFaxSources();
			
			if(faxSourceList != null) {
				System.out.println("Fax Sources list size :: " + faxSourceList.size());
								
				result = new ResponseEntity<List<FaxSource>>(faxSourceList, HttpStatus.OK);
			}else {
				result = new ResponseEntity<List<FaxSource>>(faxSourceList, HttpStatus.NOT_FOUND);
			}
		}catch(Exception ex) {
			System.out.println("Enter FaxSourceAPIController - getAllFaxSources()");
			ex.printStackTrace();
		}
		
		System.out.println("Exit FaxSourceAPIController - getAllFaxSources()");
		return result;
		
	} 
}
