/**
 * 
 */
package com.mortgagefamily.phhax.sybmt.dto;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * @author mishrari
 *
 */

@Entity
@Table(name = "dbo.FaxSource")
public class FaxSource {

	@Id
	@Column(name = "FaxSourceUniqNum")
	private long faxSourceUniqNum;
	
	@Column(name = "Description")
	private String description;
	
	@Column(name = "MailboxLocId")
	private String mailBoxLocId;
	
	@Column(name = "ServerIPAddr")
	private String serverIpAddr;
	
	@Column(name = "SortId")
	private long sortId;
	
	@Column(name = "UserCrtd")
	private String userCrtd;
	
	@Column(name = "DateCrtd")
	private Date dateCrtd;
	
	@Column(name = "UserMdfd")
	private String userMdfd;
	
	@Column(name = "DateMdfd")
	private Date dateMdfd;

	public long getFaxSourceUniqNum() {
		return faxSourceUniqNum;
	}

	public void setFaxSourceUniqNum(long faxSourceUniqNum) {
		this.faxSourceUniqNum = faxSourceUniqNum;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getMailBoxLocId() {
		return mailBoxLocId;
	}

	public void setMailBoxLocId(String mailBoxLocId) {
		this.mailBoxLocId = mailBoxLocId;
	}

	public String getServerIpAddr() {
		return serverIpAddr;
	}

	public void setServerIpAddr(String serverIpAddr) {
		this.serverIpAddr = serverIpAddr;
	}

	public long getSortId() {
		return sortId;
	}

	public void setSortId(long sortId) {
		this.sortId = sortId;
	}

	public String getUserCrtd() {
		return userCrtd;
	}

	public void setUserCrtd(String userCrtd) {
		this.userCrtd = userCrtd;
	}

	public Date getDateCrtd() {
		return dateCrtd;
	}

	public void setDateCrtd(Date dateCrtd) {
		this.dateCrtd = dateCrtd;
	}

	public String getUserMdfd() {
		return userMdfd;
	}

	public void setUserMdfd(String userMdfd) {
		this.userMdfd = userMdfd;
	}

	public Date getDateMdfd() {
		return dateMdfd;
	}

	public void setDateMdfd(Date dateMdfd) {
		this.dateMdfd = dateMdfd;
	}
		
	
}
