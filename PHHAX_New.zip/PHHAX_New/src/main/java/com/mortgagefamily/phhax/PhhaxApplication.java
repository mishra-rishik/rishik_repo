package com.mortgagefamily.phhax;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication//(scanBasePackages={"com.mortgagefamily.phhax"})
public class PhhaxApplication {

	public static void main(String[] args) {
		SpringApplication.run(PhhaxApplication.class, args);
	}
}
