/**
 * 
 */
package com.mortgagefamily.phhax.config;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;
import java.util.stream.Collectors;

import javax.persistence.EntityManagerFactory;
import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.autoconfigure.jdbc.DataSourceBuilder;
import org.springframework.boot.autoconfigure.jdbc.DataSourceProperties;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.orm.jpa.EntityManagerFactoryBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;
import org.springframework.core.io.support.PropertiesLoaderUtils;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.orm.jpa.JpaTransactionManager;
import org.springframework.orm.jpa.LocalContainerEntityManagerFactoryBean;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.annotation.EnableTransactionManagement;

/**
 * @author mishrari
 *
 */

@Configuration
@EnableTransactionManagement
@EnableJpaRepositories(
			entityManagerFactoryRef = "cdmsEntityManager", 
			transactionManagerRef = "cdmsTransactionManager", 
			basePackages = "com.mortgagefamily.phhax.cdms.dao" 
)
public class DBOracleConfig {

	
	@Primary
	@Bean(name = "cdmsDataSource")
	@ConfigurationProperties(prefix = "spring.cdms.datasource")
	public DataSource cdmsDataSource() {
		return DataSourceBuilder.create().build();
	}
	 

	@Bean("cdmsDataSourceProperties")
	@Primary
	@ConfigurationProperties("spring.cdms.datasource")
	public DataSourceProperties cdmsDataSourceProperties() {
		return new DataSourceProperties();
	}

	/*@Bean("cdmsDataSource")
	@Primary
	@ConfigurationProperties("spring.cdms.datasource")
	public DataSource cdmsDataSource(
			@Qualifier("cdmsDataSourceProperties") DataSourceProperties cdmsDataSourceProperties) {
		return cdmsDataSourceProperties().initializeDataSourceBuilder().build();
	}*/

	/*@Primary
	@Bean(name = "cdmsEntityManager")
	public LocalContainerEntityManagerFactoryBean cdmsEntityManagerFactory(EntityManagerFactoryBuilder builder,
			@Qualifier("cdmsDataSource") DataSource cdmsDataSource) {
		return builder
				.dataSource(cdmsDataSource)
				.packages("com.mortgagefamily.phhax.cdms.dto")
				.persistenceUnit("cdms")
				.properties(additionalJpaProperties()).build();
	}*/
	
	@Primary
	@Bean(name = "cdmsEntityManager")
	public LocalContainerEntityManagerFactoryBean cdmsEntityManagerFactory(EntityManagerFactoryBuilder builder) {
		return builder
				.dataSource(cdmsDataSource())
				.packages("com.mortgagefamily.phhax.cdms.dto")
				.persistenceUnit("cdms")
				.properties(hibernateProperties()).
				build();
	}

	@Primary
	private Map additionalJpaProperties() {
		Map map = new HashMap<>();

		map.put("hibernate.dialect", "org.hibernate.dialect.Oracle10gDialect");

		return map;
	}

	@Primary
	@Bean(name = "cdmsTransactionManager")
	public PlatformTransactionManager cdmsTransactionManager(
			@Qualifier("cdmsEntityManager") EntityManagerFactory entityManagerFactory) {
		return new JpaTransactionManager(entityManagerFactory);
	}

	
	private Map<String, Object> hibernateProperties() {

		Resource resource = new ClassPathResource("hibernate.properties");
		try {
			Properties properties = PropertiesLoaderUtils.loadProperties(resource);
			return properties.entrySet().stream()
											.collect(Collectors.toMap(
														e -> e.getKey().toString(),
														e -> e.getValue())
													);
		} catch (IOException e) {
			return new HashMap<String, Object>();
		}
	}
}
