/**
 * 
 */
package com.mortgagefamily.phhax.config;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;
import java.util.stream.Collectors;

import javax.persistence.EntityManagerFactory;
import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.autoconfigure.jdbc.DataSourceBuilder;
import org.springframework.boot.autoconfigure.jdbc.DataSourceProperties;
import org.springframework.boot.context.properties.ConfigurationProperties;

import org.springframework.boot.orm.jpa.EntityManagerFactoryBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;
import org.springframework.core.io.support.PropertiesLoaderUtils;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.orm.jpa.JpaTransactionManager;
import org.springframework.orm.jpa.LocalContainerEntityManagerFactoryBean;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.annotation.EnableTransactionManagement;

/**
 * @author mishrari
 *
 */

@Configuration
@EnableTransactionManagement
@EnableJpaRepositories(
		entityManagerFactoryRef = "sybmtEntityManager",
        transactionManagerRef = "sybmtTransactionManager",
        basePackages = { "com.mortgagefamily.phhax.sybmt.dao" })
public class DBSybaseConfig {
		
	@Bean(name = "sybmtDataSource")
	@ConfigurationProperties(prefix = "spring.sybmt.datasource")
	public DataSource sybmtDataSource() {
		return DataSourceBuilder.create().build();
	}
	 

	@Bean("sybmtDataSourceProperties")
	@ConfigurationProperties("spring.sybmt.datasource")
	public DataSourceProperties sybmtDataSourceProperties() {
		return new DataSourceProperties();
	}

	/*@Bean("sybmtDataSource")	
	@ConfigurationProperties("sybmt.datasource")
	public DataSource sybmtDataSource(
			@Qualifier("sybmtDataSourceProperties") DataSourceProperties sybmtDataSourceProperties) {
		return sybmtDataSourceProperties().initializeDataSourceBuilder().build();
	}*/


	/*@Bean(name = "sybmtEntityManagerFactory")
	public LocalContainerEntityManagerFactoryBean sybmtEntityManagerFactory(EntityManagerFactoryBuilder builder,
			@Qualifier("sybmtDataSource") DataSource sybmtDataSource) {
		return builder.dataSource(sybmtDataSource).packages("com.mortgagefamily.phhax.sybmt.dto").persistenceUnit("sybmt")
				.properties(additionalJpaProperties()).build();
	}*/
	
	
	@Bean(name = "sybmtEntityManager")
	public LocalContainerEntityManagerFactoryBean sybmtEntityManagerFactory(EntityManagerFactoryBuilder builder) {
		return builder
				.dataSource(sybmtDataSource())
				.packages("com.mortgagefamily.phhax.sybmt.dto")
				.persistenceUnit("sybmt")
				.properties(hibernateProperties()).
				build();
	}

	private Map additionalJpaProperties() {
		Map map = new HashMap<>();

		map.put("hibernate.dialect", "org.hibernate.dialect.SybaseDialect");

		return map;
	}

	
	@Bean(name = "sybmtTransactionManager")
	public PlatformTransactionManager sybmtTransactionManager(
			@Qualifier("sybmtEntityManager") EntityManagerFactory entityManagerFactory) {
		return new JpaTransactionManager(entityManagerFactory);
	}
	
	private Map<String, Object> hibernateProperties() {

		Resource resource = new ClassPathResource("hibernate.properties");
		try {
			Properties properties = PropertiesLoaderUtils.loadProperties(resource);
			properties.put("hibernate.dialect", "org.hibernate.dialect.SybaseDialect");
			return properties.entrySet().stream()
											.collect(Collectors.toMap(
														e -> e.getKey().toString(),
														e -> e.getValue())
													);
		} catch (IOException e) {
			return new HashMap<String, Object>();
		}
	}

}
