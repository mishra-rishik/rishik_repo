/**
 * 
 */
package com.mortgagefamily.phhax.cdms.dto;

import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.Table;

/**
 * @author mishrari
 *
 */

@Entity
@Table(name = "CENDANT_DOCUMENT_TYPE_CAT")
public class DocTypeCat {

	@Id
	//@SequenceGenerator(name = "docCatIDSeqGen", sequenceName = "CDMS_SEQUENCE", initialValue = 5, allocationSize = 10000)
	//@GeneratedValue(generator = "docCatIDSeqGen")
	@Column(name = "DOCUMENT_CAT_ID")
	private long documentCatId;
	
	
	@Column(name="DOCUMENT_CAT_DESC")
	private String documentCatDesc;
	
	
	@OneToMany(cascade= { CascadeType.ALL}, fetch = FetchType.LAZY)
	@JoinColumn(name = "document_cat_id")
    private Set<DocType> docTypes;


	public long getDocumentCatId() {
		return documentCatId;
	}


	public void setDocumentCatId(long documentCatId) {
		this.documentCatId = documentCatId;
	}


	public String getDocumentCatDesc() {
		return documentCatDesc;
	}


	public void setDocumentCatDesc(String documentCatDesc) {
		this.documentCatDesc = documentCatDesc;
	}


	public Set<DocType> getDocTypes() {
		return docTypes;
	}


	public void setDocTypes(Set<DocType> docTypes) {
		this.docTypes = docTypes;
	}
	
	
}
