/**
 * 
 */
package com.mortgagefamily.phhax.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.mortgagefamily.phhax.cdms.dto.DocTypeCat;



/**
 * @author rishi
 *
 */


public interface IDocTypeService {
	
	List<DocTypeCat> getAllDocTypeCats();

	
}
