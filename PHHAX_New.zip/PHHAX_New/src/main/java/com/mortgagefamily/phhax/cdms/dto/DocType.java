/**
 * 
 */
package com.mortgagefamily.phhax.cdms.dto;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * @author mishrari
 *
 */

@Entity
@Table(name = "CENDANT_DOCUMENT_TYPE")
public class DocType {

	@Id
	//@SequenceGenerator(name = "docTypeIDSeqGen", sequenceName = "CDMS_SEQUENCE", initialValue = 5, allocationSize = 10000)
	//@GeneratedValue(generator = "docTypeIDSeqGen")
	@Column(name = "DOCUMENT_TYPE_ID")
	private long documentTypeId;
	
	
	@Column(name="DOCUMENT_DESC")
	private String documentDesc;
	
	@Column(name="ACTIVE_FLAG")
	private String activeFlag;

	public long getDocumentTypeId() {
		return documentTypeId;
	}

	public void setDocumentTypeId(long documentTypeId) {
		this.documentTypeId = documentTypeId;
	}

	public String getDocumentDesc() {
		return documentDesc;
	}

	public void setDocumentDesc(String documentDesc) {
		this.documentDesc = documentDesc;
	}

	public String getActiveFlag() {
		return activeFlag;
	}

	public void setActiveFlag(String activeFlag) {
		this.activeFlag = activeFlag;
	}
		
	/*@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "document_cat_id", nullable = false)
	//@JsonBackReference
	@JsonIgnore
	private DocTypeCat docTypeCat;*/
		
	 
}
