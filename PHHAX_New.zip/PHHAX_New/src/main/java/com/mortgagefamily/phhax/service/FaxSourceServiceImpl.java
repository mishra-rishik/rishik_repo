/**
 * 
 */
package com.mortgagefamily.phhax.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mortgagefamily.phhax.sybmt.dao.FaxSourceDAO;
import com.mortgagefamily.phhax.sybmt.dto.FaxSource;

/**
 * @author mishrari
 *
 */

@Service
public class FaxSourceServiceImpl implements IFaxSourceService {

	/* (non-Javadoc)
	 * @see com.mortgagefamily.phhax.service.IFaxSourceService#getAllFaxSources()
	 */
	
	@Autowired
	FaxSourceDAO faxSourceDAO;
	
	@Override
	public List<FaxSource> getAllFaxSources() {
		// TODO Auto-generated method stub
		return faxSourceDAO.findAll();
	}

}
