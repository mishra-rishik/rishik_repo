/**
 * 
 */
package com.mortgagefamily.phhax.service;

import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mortgagefamily.phhax.cdms.dao.DocCatDAO;
import com.mortgagefamily.phhax.cdms.dto.DocTypeCat;


/**
 * @author RM
 *
 */

@Service
public class IDocTypeServiceImpl implements IDocTypeService {
	
	@Autowired
	private DocCatDAO docCatDAO;

	@Override
	public List<DocTypeCat> getAllDocTypeCats() {
		// TODO Auto-generated method stub
		return docCatDAO.findAll();
	}
	
	

}
