/**
 * 
 */
package com.rm.fsd.springboot.skillTracker.service;

import java.util.List;

import com.rm.fsd.springboot.skillTracker.dto.AssociateSkill;


/**
 * @author rishi
 *
 */
public interface IAssociateSkillService {
	
	List<Object[]> getCountBySkill();
	
	List<AssociateSkill> getAssociateSkillsBySkillId(Long skillId);

}
