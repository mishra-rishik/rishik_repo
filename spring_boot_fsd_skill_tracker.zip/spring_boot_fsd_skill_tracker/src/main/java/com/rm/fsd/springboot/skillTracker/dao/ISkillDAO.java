/**
 * 
 */
package com.rm.fsd.springboot.skillTracker.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.rm.fsd.springboot.skillTracker.dto.Skill;

/**
 * @author Rishik Mishra
 *
 */

@Repository
public interface ISkillDAO extends JpaRepository<Skill, Long> {

}
