/**
 * 
 */
package com.rishik.fsd.springboot.security.dto;

/**
 * @author rishi
 *
 */
public enum TimeUnit {
	HOUR,MINUTE;
}
