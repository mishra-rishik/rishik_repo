/**
 * 
 */
package com.rishik.fsd.springboot.security.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.rishik.fsd.springboot.security.dto.WorkOutTxn;
import com.rishik.fsd.springboot.security.dto.WorkOutUser;

/**
 * @author rishi
 *
 */

@Repository
public interface IWorkOutTransactionDAO extends JpaRepository<WorkOutTxn, Long> {

	
}
