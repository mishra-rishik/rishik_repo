/**
 * 
 */
package com.rishik.fsd.springboot.security.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.rishik.fsd.springboot.security.dao.IWorkOutDAO;
import com.rishik.fsd.springboot.security.dto.WorkOut;

/**
 * @author rishi
 *
 */

@Service
public class WorkOutServiceImpl implements IWorkOutService {
	
	@Autowired
	private IWorkOutDAO workOutDao;

	/* (non-Javadoc)
	 * @see com.rishik.fsd.springboot.service.IWorkOutService#getWorkOutByID(java.lang.Long)
	 */
	@Override
	public WorkOut getWorkOutByID(Long id) {
		// TODO Auto-generated method stub
		return (WorkOut) workOutDao.getOne(id);
	}

	/* (non-Javadoc)
	 * @see com.rishik.fsd.springboot.service.IWorkOutService#getWorkOutByTitle(java.lang.String)
	 */
	
	/*@Override
	public WorkOut getWorkOutByTitle(String title) {
		// TODO Auto-generated method stub
		WorkOut workOut = null;
		List<WorkOut> workOutList = workOutDao.findByworkOutTitle(title);
		
		if(workOutList != null && !workOutList.isEmpty()) {
			workOut = (WorkOut)workOutList.get(0);
		}
		
		return workOut;
	}*/

	/* (non-Javadoc)
	 * @see com.rishik.fsd.springboot.service.IWorkOutService#saveWorkOut(com.rishik.fsd.springboot.security.dto.WorkOut)
	 */
	@Transactional
	@Override
	public boolean saveWorkOut(WorkOut workOut) {
		
		boolean done = false;
		// TODO Auto-generated method stub
		workOutDao.save(workOut);
		done=true;
		return done;
	}

	/* (non-Javadoc)
	 * @see com.rishik.fsd.springboot.service.IWorkOutService#updateWorkOut(com.rishik.fsd.springboot.security.dto.WorkOut)
	 */
	@Transactional
	@Override
	public boolean updateWorkOut(WorkOut workOut) {
		boolean done = false;
		// TODO Auto-generated method stub
		workOutDao.save(workOut);
		done=true;
		return done;
	}
	
	@Transactional
	@Override
	public boolean deleteWorkOut(Long id) {
		boolean done = false;
		// TODO Auto-generated method stub
		workOutDao.deleteById(id);
		done=true;
		return done;
	}

}
