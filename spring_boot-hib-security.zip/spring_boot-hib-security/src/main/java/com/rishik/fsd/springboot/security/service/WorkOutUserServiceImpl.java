package com.rishik.fsd.springboot.security.service;

import java.util.List;

import javax.transaction.Transactional;

import org.hibernate.criterion.Example;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.repository.query.QueryByExampleExecutor;
import org.springframework.stereotype.Service;

import com.rishik.fsd.springboot.security.dao.IWorkOutUserDAO;
import com.rishik.fsd.springboot.security.dto.WorkOutUser;

@Service
public class WorkOutUserServiceImpl implements IWorkOutUserService {

	@Autowired
	private IWorkOutUserDAO userDao;
	
	@Override
	public WorkOutUser getUserByID(Long id) {
		// TODO Auto-generated method stub
		return userDao.getOne(id);
	}

	@Override
	public WorkOutUser getUserByName(String userName) {
		// TODO Auto-generated method stub
		WorkOutUser user = null;
		List<WorkOutUser> users = userDao.findByUserName(userName);
		if(users != null && !users.isEmpty()) {
			user = (WorkOutUser)users.get(0);
		}
		
		return user;
	}

	@Transactional
	@Override
	public boolean registerUser(WorkOutUser user) {
		
		boolean done = false;
		// TODO Auto-generated method stub
		userDao.save(user);
		done=true;
		return done;
	}

	@Transactional
	@Override
	public boolean updateUser(WorkOutUser user) {
		boolean done = false;
		// TODO Auto-generated method stub
		userDao.save(user);
		done=true;
		return done;
	}

}
