package com.rishik.fsd.springboot.security.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.rishik.fsd.springboot.security.dto.WorkOutUser;


@Repository
public interface IWorkOutUserDAO extends JpaRepository<WorkOutUser, Long> {

	List<WorkOutUser> findByUserName(String userName);
}
