/**
 * 
 */
package com.rishik.fsd.springboot.security.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.rishik.fsd.springboot.security.dto.WorkOut;


/**
 * @author rishi
 * @param <WorkOut>
 *
 */

@Repository
public interface IWorkOutDAO extends JpaRepository<WorkOut, Long> {
		
	
}
