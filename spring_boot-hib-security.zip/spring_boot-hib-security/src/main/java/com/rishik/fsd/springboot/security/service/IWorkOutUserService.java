package com.rishik.fsd.springboot.security.service;

import com.rishik.fsd.springboot.security.dto.WorkOutUser;


public interface IWorkOutUserService {
	
	WorkOutUser getUserByID(Long id);

	WorkOutUser getUserByName(String userName);
	
	boolean registerUser(WorkOutUser user);
	
	boolean updateUser(WorkOutUser user);
	
}
