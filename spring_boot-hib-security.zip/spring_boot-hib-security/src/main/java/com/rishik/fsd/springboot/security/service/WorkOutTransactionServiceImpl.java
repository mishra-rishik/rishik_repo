/**
 * 
 */
package com.rishik.fsd.springboot.security.service;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.rishik.fsd.springboot.security.dao.IWorkOutDAO;
import com.rishik.fsd.springboot.security.dao.IWorkOutTransactionDAO;
import com.rishik.fsd.springboot.security.dto.WorkOutTxn;

/**
 * @author rishi
 *
 */

@Service
public class WorkOutTransactionServiceImpl implements IWorkOutTransactionService {
	
	@Autowired
	private IWorkOutTransactionDAO workOutTransDao;

	/* (non-Javadoc)
	 * @see com.rishik.fsd.springboot.service.IWorkOutTransactionService#getWorkOutTransactionByID(java.lang.Long)
	 */
	@Override
	public WorkOutTxn getWorkOutTransactionByID(Long id) {
		// TODO Auto-generated method stub
		return workOutTransDao.getOne(id);
	}

	/* (non-Javadoc)
	 * @see com.rishik.fsd.springboot.service.IWorkOutTransactionService#saveWorkOutTransaction(com.rishik.fsd.springboot.security.dto.WorkOutTxn)
	 */
	@Override
	@Transactional
	public boolean saveWorkOutTransaction(WorkOutTxn workOutTrans) {
		boolean done = false;
		// TODO Auto-generated method stub
		workOutTransDao.save(workOutTrans);
		done=true;
		return done;
	}

}
