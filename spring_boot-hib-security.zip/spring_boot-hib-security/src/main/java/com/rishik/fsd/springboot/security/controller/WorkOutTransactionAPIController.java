/**
 * 
 */
package com.rishik.fsd.springboot.security.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.rishik.fsd.springboot.security.dto.WorkOutTxn;
import com.rishik.fsd.springboot.security.dto.WorkOutUser;
import com.rishik.fsd.springboot.security.service.IWorkOutTransactionService;
import com.rishik.fsd.springboot.security.service.IWorkOutUserService;

/**
 * @author rishi
 *
 */

@RestController
@RequestMapping("/trans")
public class WorkOutTransactionAPIController {

	@Autowired
	private IWorkOutTransactionService transService;
	
	@RequestMapping(value = "/{id}", method = RequestMethod.GET)
	public ResponseEntity<WorkOutTxn> getTransaction(@PathVariable("id") Long id) {
		ResponseEntity<WorkOutTxn> result = null;
		
		WorkOutTxn transaction = transService.getWorkOutTransactionByID(id);
		
		if(transaction != null) {
			result = new ResponseEntity<WorkOutTxn>(transaction, HttpStatus.OK);
		}else {
			result = new ResponseEntity<WorkOutTxn>(transaction, HttpStatus.NOT_FOUND);
		}
		return result;
		
	}
	
	@PostMapping(value = "/")
	public ResponseEntity<WorkOutTxn> saveTransaction(@RequestBody WorkOutTxn transaction) {

		boolean successFlag = false;
		ResponseEntity<WorkOutTxn> result = null;
		
		if(transaction != null) {
			successFlag = transService.saveWorkOutTransaction(transaction);
		}
		
		if(successFlag) {
			result = new ResponseEntity<WorkOutTxn>(transaction, HttpStatus.CREATED);
		}else {
			result = new ResponseEntity<WorkOutTxn>(transaction, HttpStatus.NOT_FOUND);
		}

		return result;
	}
}
