/**
 * 
 */
package com.rishik.fsd.springboot.security.service;

import com.rishik.fsd.springboot.security.dto.WorkOut;
import com.rishik.fsd.springboot.security.dto.WorkOutUser;

/**
 * @author rishi
 *
 */
public interface IWorkOutService {

	WorkOut getWorkOutByID(Long id);
		
	boolean saveWorkOut(WorkOut workOut);
	
	boolean updateWorkOut(WorkOut workOut);
	
	boolean deleteWorkOut(Long id);
}
