/**
 * 
 */
package com.rishik.fsd.springboot.security.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.rishik.fsd.springboot.security.dto.WorkOutUser;
import com.rishik.fsd.springboot.security.service.IWorkOutUserService;

/**
 * @author rishi
 *
 */

@RestController
@RequestMapping("/users")
public class WorkOutUserAPIController {

	@Autowired
	private IWorkOutUserService userService;
	
	@RequestMapping(value = "/{userName}", method = RequestMethod.GET)
	public ResponseEntity<WorkOutUser> getUser(@PathVariable("userName") String userName) {
		ResponseEntity<WorkOutUser> result = null;
		
		WorkOutUser user = userService.getUserByName(userName);
		
		if(user != null) {
			result = new ResponseEntity<WorkOutUser>(user, HttpStatus.OK);
		}else {
			result = new ResponseEntity<WorkOutUser>(user, HttpStatus.NOT_FOUND);
		}
		return result;
		
	}
	
	@PostMapping(value = "/")
	public ResponseEntity<WorkOutUser> createUser(@RequestBody WorkOutUser user) {

		boolean successFlag = false;
		ResponseEntity<WorkOutUser> result = null;
		
		if(user != null) {
			successFlag = userService.registerUser(user);
		}
		
		if(successFlag) {
			result = new ResponseEntity<WorkOutUser>(user, HttpStatus.CREATED);
		}else {
			result = new ResponseEntity<WorkOutUser>(user, HttpStatus.NOT_FOUND);
		}

		return result;
	}
	
	@PutMapping("/{id}")
	public ResponseEntity<WorkOutUser> updateUser(@PathVariable("id") Long id, @RequestBody WorkOutUser user) {

		boolean updateFlag = false;
		ResponseEntity<WorkOutUser> result = null;
		
		if(id != null && user != null) {
			updateFlag = userService.updateUser(user);
		}
		
		if(updateFlag) {
			result =  new ResponseEntity<WorkOutUser>(user, HttpStatus.OK);
		}else {
			result =  new ResponseEntity<WorkOutUser>(user, HttpStatus.NOT_FOUND);
		}
				
		return result;
	}
}
