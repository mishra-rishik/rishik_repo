/**
 * 
 */
package com.rishik.fsd.springboot.security.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.rishik.fsd.springboot.security.dto.WorkOut;
import com.rishik.fsd.springboot.security.dto.WorkOutUser;
import com.rishik.fsd.springboot.security.service.IWorkOutService;
import com.rishik.fsd.springboot.security.service.IWorkOutUserService;

/**
 * @author rishi
 *
 */

@RestController
@RequestMapping("/workouts")
public class WorkOutAPIController {

	@Autowired
	private IWorkOutService workOutService;
	
	@RequestMapping(value = "/{id}", method = RequestMethod.GET)
	public ResponseEntity<WorkOut> getWorkOut(@PathVariable("id") Long id) {
		ResponseEntity<WorkOut> result = null;
		
		WorkOut workOut = workOutService.getWorkOutByID(id);
		
		if(workOut != null) {
			result = new ResponseEntity<WorkOut>(workOut, HttpStatus.OK);
		}else {
			result = new ResponseEntity<WorkOut>(workOut, HttpStatus.NOT_FOUND);
		}
		return result;
		
	}
	
	@PostMapping(value = "/")
	public ResponseEntity<WorkOut> saveWorkOut(@RequestBody WorkOut workOut) {

		boolean saveSuccessFlag = false;
		ResponseEntity<WorkOut> result = null;
		
		if(workOut != null) {
			saveSuccessFlag = workOutService.saveWorkOut(workOut);
		}
		
		if(saveSuccessFlag) {
			result = new ResponseEntity<WorkOut>(workOut, HttpStatus.CREATED);
		}else {
			result = new ResponseEntity<WorkOut>(workOut, HttpStatus.NOT_FOUND);
		}

		return result;
	}
	
	@PutMapping("/{id}")
	public ResponseEntity<WorkOut> updateWorkOut(@PathVariable("id") Long id, @RequestBody WorkOut workOut) {

		boolean updateFlag = false;
		ResponseEntity<WorkOut> result = null;
		
		if(id != null && workOut != null) {
			updateFlag = workOutService.updateWorkOut(workOut);
		}
		
		if(updateFlag) {
			result =  new ResponseEntity<WorkOut>(workOut, HttpStatus.OK);
		}else {
			result =  new ResponseEntity<WorkOut>(workOut, HttpStatus.NOT_FOUND);
		}
				
		return result;
	}
	
	@DeleteMapping("/{id}")
	public ResponseEntity<Void> deleteWorkOut(@PathVariable("id") Long id) {

		boolean deleteFlag = false;
		ResponseEntity<Void> result = null;
		
		if(id != null) {
			deleteFlag = workOutService.deleteWorkOut(id);
		}
		
		if(deleteFlag) {
			result =  new ResponseEntity(id, HttpStatus.GONE);
		}else {
			result =  new ResponseEntity(id, HttpStatus.NOT_FOUND);
		}
				
		return result;

	}
}
