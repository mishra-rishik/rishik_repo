/**
 * 
 */
package com.rishik.fsd.springboot.security.dto;

import java.time.LocalDateTime;
import java.util.Calendar;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.PrimaryKeyJoinColumn;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 * @author rishi
 *
 */

@Entity
@Table(name = "WORKOUT_TRANS")
public class WorkOutTxn implements Comparable<WorkOutTxn>{
	
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name = "TRANS_ID", unique = true, nullable = false)
	private Long transactionId;
	
	@Temporal(TemporalType.TIME)
	@Column(name = "START_TIME")
	private Date startTime;
	
	@Temporal(TemporalType.TIME)
	@Column(name = "END_TIME")
	private Date endTime;
	
	@Column(name = "CAL_BURNT")
	private Double calBurnt;
	
		
	@ManyToOne
	@JoinColumn
	private WorkOut workout;

	public Long getTransactionId() {
		return transactionId;
	}

	public void setTransactionId(Long transactionId) {
		this.transactionId = transactionId;
	}

	public Date getStartTime() {
		return startTime;
	}

	public void setStartTime(Date startTime) {
		this.startTime = startTime;
	}

	public Date getEndTime() {
		return endTime;
	}

	public void setEndTime(Date endTime) {
		this.endTime = endTime;
	}

	public Double getCalBurnt() {
		return calBurnt;
	}

	public void setCalBurnt(Double calBurnt) {
		this.calBurnt = calBurnt;
	}
	

	public WorkOut getWorkout() {
		return workout;
	}

	public void setWorkout(WorkOut workout) {
		this.workout = workout;
	}

	@Override
	public int compareTo(WorkOutTxn o) {
		// TODO Auto-generated method stub
		return this.transactionId.compareTo(o.transactionId);
	}
	

}
