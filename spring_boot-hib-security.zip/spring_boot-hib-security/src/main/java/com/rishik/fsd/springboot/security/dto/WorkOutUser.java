/**
 * 
 */
package com.rishik.fsd.springboot.security.dto;

import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Transient;
import javax.validation.constraints.NotNull;

import com.fasterxml.jackson.annotation.JsonIgnore;


/**
 * @author rishi
 *
 */

@Entity
@Table(name = "WORKOUT_USER")
public class WorkOutUser implements Comparable<WorkOutUser>{

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name = "USERID", unique = true, nullable = false)
	private Long userId;
	
	@NotNull
	@Column(name="USERNAME",unique=true)
	private String userName;
	
	@NotNull
	@Column(name="PASSWORD")
	private String password;
	
	@Transient
	private String retypePassword;
	
	@JsonIgnore
	@OneToMany(fetch = FetchType.LAZY,cascade=CascadeType.REMOVE,mappedBy="user")
	private Set<WorkOut> workOutSet;

	public Long getUserId() {
		return userId;
	}

	public void setUserId(Long userId) {
		this.userId = userId;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getRetypePassword() {
		return retypePassword;
	}

	public void setRetypePassword(String retypePassword) {
		this.retypePassword = retypePassword;
	}
	
	
	public Set<WorkOut> getWorkOutSet() {
		return workOutSet;
	}

	public void setWorkOutSet(Set<WorkOut> workOutSet) {
		this.workOutSet = workOutSet;
	}

	public WorkOutUser(Long userId, @NotNull String userName, @NotNull String password, String retypePassword) {
		super();
		this.userId = userId;
		this.userName = userName;
		this.password = password;
		this.retypePassword = retypePassword;
	}
	
	public WorkOutUser() {
		
	}

	@Override
	public int compareTo(WorkOutUser o) {
		// TODO Auto-generated method stub
		return this.userId.compareTo(o.userId);
	}
	
}
