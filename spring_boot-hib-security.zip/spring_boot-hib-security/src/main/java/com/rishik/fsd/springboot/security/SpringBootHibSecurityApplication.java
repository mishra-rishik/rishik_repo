package com.rishik.fsd.springboot.security;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

@SpringBootApplication
@ComponentScan({"com.rishik.fsd.springboot.security"})
public class SpringBootHibSecurityApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootHibSecurityApplication.class, args);
	}
}
