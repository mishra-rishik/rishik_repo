/**
 * 
 */
package com.rishik.fsd.springboot.security.dto;

import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Transient;
import javax.validation.constraints.NotNull;

import com.fasterxml.jackson.annotation.JsonIgnore;


/**
 * @author rishi
 *
 */

@Entity
@Table(name = "WORKOUTS")
public class WorkOut implements Comparable<WorkOut>{

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name = "WORKOUT_ID", unique = true, nullable = false)
	private Long workoutId;
	
	@NotNull
	@Column(name="WORKOUT_NAME",unique=true)
	private String workOutTitle;
	
	@NotNull
	@Column(name="CALORIES_PER_UNIT")
	private Double calsBurntPerUnit;
	
	
	@Column(name="WORKOUT_UNIT")
	@Enumerated(EnumType.STRING)
	private TimeUnit unit;
	
	@ManyToOne
    @JoinColumn(name="userId")
	private WorkOutUser user;
	
	@JsonIgnore
	@OneToMany(mappedBy="workout",fetch=FetchType.LAZY,cascade=CascadeType.REMOVE)
	private Set<WorkOutTxn> transactions;

	public Long getWorkoutId() {
		return workoutId;
	}

	public void setWorkoutId(Long workoutId) {
		this.workoutId = workoutId;
	}

	public String getWorkOutTitle() {
		return workOutTitle;
	}

	public void setWorkOutTitle(String workoutTitle) {
		this.workOutTitle = workoutTitle;
	}

	public Double getCalsBurntPerUnit() {
		return calsBurntPerUnit;
	}

	public void setCalsBurntPerUnit(Double calsBurntPerUnit) {
		this.calsBurntPerUnit = calsBurntPerUnit;
	}

	public TimeUnit getUnit() {
		return unit;
	}

	public void setUnit(TimeUnit unit) {
		this.unit = unit;
	}

	public WorkOutUser getUser() {
		return user;
	}

	public void setUser(WorkOutUser user) {
		this.user = user;
	}
	
	

	public Set<WorkOutTxn> getTransactions() {
		return transactions;
	}

	public void setTransactions(Set<WorkOutTxn> transactions) {
		this.transactions = transactions;
	}

	@Override
	public int compareTo(WorkOut workOut) {
		// TODO Auto-generated method stub
		return this.workoutId.compareTo(workOut.workoutId);
	}

	
	
	
}
