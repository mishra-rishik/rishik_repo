/**
 * 
 */
package com.rishik.fsd.springboot.security.service;

import com.rishik.fsd.springboot.security.dto.WorkOutTxn;

/**
 * @author rishi
 *
 */
public interface IWorkOutTransactionService {

	WorkOutTxn getWorkOutTransactionByID(Long id);
	
	boolean saveWorkOutTransaction(WorkOutTxn workOutTrans);
	
	
}
